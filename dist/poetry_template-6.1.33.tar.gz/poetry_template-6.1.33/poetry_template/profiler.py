import cProfile

import runner  # noqa

cProfile.run("runner.main(None)")
